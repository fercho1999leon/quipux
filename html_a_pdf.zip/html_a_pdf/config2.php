<?php
	$nombre_servidor = "http://mauricio.informatica.gov.ec/html_a_pdf";
    $tipo_sistema = "Capacitación";
?>
